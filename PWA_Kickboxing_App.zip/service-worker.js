self.addEventListener("install", e => {
  e.waitUntil(
    caches.open("kickboxing-cache").then(cache => {
      return cache.addAll([
        "/mnt/data/pwa_app/index.html",
        "manifest.json"
      ]);
    })
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    caches.match(e.request).then(response => response || fetch(e.request))
  );
});
